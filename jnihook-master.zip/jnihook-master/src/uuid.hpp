#ifndef _UUID_HPP_
#define _UUID_HPP_

#include <string>

std::string
GenerateUuid();

#endif
